package social;

public class GroupExistsException extends Exception {
  private static final long serialVersionUID = 1L;

}
